from zliact.core import LegalIACTChecker

def test_add_requirement():
    checker = LegalIACTChecker()
    res = checker.add_requirement("RGPD")
    assert "RGPD" in res
