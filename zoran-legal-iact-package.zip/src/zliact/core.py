class LegalIACTChecker:
    def __init__(self):
        self.requirements = []
    def add_requirement(self, req):
        self.requirements.append(req)
        return f"Exigence ajoutée : {req}"
    def generate_checklist(self):
        return [f"Vérifier : {req}" for req in self.requirements]
