from zliact.core import LegalIACTChecker

checker = LegalIACTChecker()
checker.add_requirement("AI Act")
print(checker.generate_checklist())
